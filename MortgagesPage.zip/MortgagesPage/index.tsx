// import React from "react";
// import AssetTable, { IMSData } from "../MortgageTable";

// import { Mortgage } from "@daml.js/create-daml-app/";
// import { useStreamQueries } from "@daml/react";

// const SecuritiesPage: React.FC = () => {
//   const mbsData = useStreamQueries(Mortgage.MBS);

//   if (mbsData.loading) return <div>Loading</div>;

//   if (mbsData.contracts.length === 0) return <div>NO Data</div>;
//   let bankNames = ["ANZ Bank", "Westpac Bank", "NAB", "Commonwealth Bank"];

//   const msFinalData: Array<IMSData> = mbsData.contracts.map((mbs, index) => {
//     let temp: IMSData = {
//       id: index + 1,
//       institution: bankNames[(index + 1) % 4],
//       securityName:
//         bankNames[(index + 1) % 4] + " RMBS Securities " + (index + 1),
//       totalValue: mbs.payload.asset_value,
//       currentValue: mbs.payload.credit_score,
//       ageReturns: mbs.payload.credit_score_deviation,
//     };
//     return temp;
//   });

//   return <AssetTable assets={msFinalData} />;
// };

// export default SecuritiesPage;
