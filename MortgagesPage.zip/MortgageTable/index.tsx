// import React from "react";
// import {
//   TableCell,
//   TableRow,
//   TableBody,
//   Table,
//   TableHead,
//   TableContainer,
//   Paper,
// } from "@material-ui/core";
// import { styled } from "@material-ui/core/styles";
// import { useHistory } from "react-router-dom";
// export interface IMSData {
//   id: number;
//   securityName: string;
//   institution: string;
//   assetValue: string;
//   totalLoan: string;
//   lvr: string;
// }

// export interface IAssetTable {
//   assets: Array<IMSData>;
// }

// const AssetTableRow: React.FC<IMSData> = ({
//   id,
//   securityName,
//   institution,
//   assetValue,
//   totalLoan,
//   lvr,
// }) => {
//   const history = useHistory();
//   const onRowClick = (assetId: number) => {
//     console.log("Cicked---------------");
//     history.push({
//       pathname: "/Asset-details",
//       state: {
//         assetId: assetId,
//       },
//     });
//   };
//   return (
//     <TableRow
//       hover
//       onClick={() => {
//         onRowClick(id);
//       }}
//       style={{ cursor: "pointer" }}
//     >
//       <CustomTableRowId>{id}</CustomTableRowId>
//       <TableCell align="right">{securityName}</TableCell>
//       <TableCell align="right">{institution}</TableCell>
//       <TableCell align="right">{assetValue}</TableCell>
//       <TableCell align="right">{totalLoan}</TableCell>
//       <TableCell align="right">{lvr}</TableCell>
//     </TableRow>
//   );
// };

// const AssetTable: React.FC<IAssetTable> = ({ assets }) => {
//   return (
//     <CustomTable>
//       <CustomTableHeader>
//         <TableRow>
//           <CustomTableCell>ID</CustomTableCell>
//           <CustomTableCell align="right">Lender Name</CustomTableCell>
//           <CustomTableCell align="right">Borrower Name</CustomTableCell>
//           <CustomTableCell align="right">Asset Value</CustomTableCell>
//           <CustomTableCell align="right">Total Loan</CustomTableCell>
//           <CustomTableCell align="right">LVR</CustomTableCell>
//         </TableRow>
//       </CustomTableHeader>
//       <TableBody>
//         {assets.map((asset, index) => {
//           return (
//             <AssetTableRow
//               id={index + 1}
//               securityName={asset.securityName}
//               institution={asset.institution}
//               assetValue={asset.assetValue}
//               totalLoan={asset.totalLoan}
//               lvr={asset.lvr}
//             />
//           );
//         })}
//       </TableBody>
//     </CustomTable>
//   );
// };

// const CustomTable = styled(Table)(({ theme }) => ({
//   width: "90%",
//   marginLeft: "5%",
//   marginTop: "6%",
// }));

// const CustomTableHeader = styled(TableHead)(({ theme }) => ({
//   background: "#3f50b5",
//   color: "white",
// }));

// const CustomTableCell = styled(TableCell)(({ theme }) => ({
//   color: "white",
//   fontSize: "1rem",
//   fontWeight: "bold",
// }));

// const CustomTableRowId = styled(TableCell)(({ theme }) => ({
//   fontWeight: "bold",
// }));

// export default AssetTable;
